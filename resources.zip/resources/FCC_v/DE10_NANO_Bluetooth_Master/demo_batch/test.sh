# file: nios2_sdk_shell_bashrc

"$SOPC_KIT_NIOS2/nios2_command_shell.sh" nios2-download HC05_Master.elf -c 1 -r -g
"$SOPC_KIT_NIOS2/nios2_command_shell.sh" nios2-terminal -c 1 

# End of file
