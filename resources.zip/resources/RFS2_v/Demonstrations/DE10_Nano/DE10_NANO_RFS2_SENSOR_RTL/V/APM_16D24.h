	
//APM16D24.h
//--APM16D24 --SLAVE ADDRESS
parameter   [7:0] APM16D24_ADDRESS           =8'h70;

// REGISTER MAP
parameter P_SYSM_CTRL    =8'h00;// RW 0x00 ALS/PS operation mode control, waitingmode control, SW reset
parameter P_INT_CTRL     =8'h01;// RW 0x03 Interrupt pin control, interrupt persistcontrol
parameter P_INT_FLAG     =8'h02;// RW 0x00 Interrupt flag, error flag, power on reset(POR) flag
parameter P_WAIT_TIME    =8'h03;// RW 0x00 Waiting time setting
parameter P_ALS_GAIN     =8'h04;// RW 0x00 ALS analog gain setting
parameter P_ALS_TIME     =8'h05;// RW 0x00 ALS integrated time setting
parameter P_LED_CTRL     =8'h06;// RW 0x00 LED setting
parameter P_PS_GAIN      =8'h07;// RW 0x00 PS analog gain setting
parameter P_PS_PULSE     =8'h08;// RW 0x00 PS number of LED pulse
parameter P_PS_TIME      =8'h09;// RW 0x00 PS integrated time setting
parameter P_PERSISTENCE  =8'h0B;// RW 0x11 ALS/PS persistence setting
parameter P_ALS_THRES_LL =8'h0C;// RW 0x00 ALS lower interrupt threshold - LSB
parameter P_ALS_THRES_LH =8'h0D;// RW 0x00 ALS lower interrupt threshold - MSB
parameter P_ALS_THRES_HL =8'h0E;// RW 0xFF ALS higher interrupt threshold - LSB
parameter P_ALS_THRES_HH =8'h0F;// RW 0xFF ALS higher interrupt threshold - MSB
parameter P_PS_THRES_LL  =8'h10;// RW 0x00 PS lower interrupt threshold - LSB
parameter P_PS_THRES_LH  =8'h11;// RW 0x00 PS lower interrupt threshold - MSB
parameter P_PS_THRES_HL  =8'h12;// RW 0xFF PS higher interrupt threshold - LSB
parameter P_PS_THRES_HH  =8'h13;// RW 0xFF PS higher interrupt threshold - MSB
parameter P_PS_OFFSET_L  =8'h14;// RW 0x00 PS offset level - LSB
parameter P_PS_OFFSET_H  =8'h15;// RW 0x00 PS offset level - MSB
parameter P_INT_SOURCE   =8'h16;// RW 0x00 ALS interrupt source
parameter P_ERROR_FLAG   =8'h17;// RW 0x00 Error flag
parameter P_PS_DATA_L    =8'h18;// R 0x00 PS output data - LSB
parameter P_PS_DATA_H    =8'h19;// R 0x00 PS output data - MSB
parameter P_IR_DATA_L    =8'h1A;// R 0x00 IR output data - LSB
parameter P_IR_DATA_H    =8'h1B;// R 0x00 IR output data - MSB
parameter P_CH0_DATA_L   =8'h1C;// R 0x00 Channel 0 output data - LSB
parameter P_CH0_DATA_H   =8'h1D;// R 0x00 Channel 0 output data - MSB
parameter P_CH1_DATA_L   =8'h1E;// R 0x00 Channel 1 output data - LSB
parameter P_CH1_DATA_H   =8'h1F;// R 0x00 Channel 1 output data - MSB
parameter P_PNO_LB       =8'hBC;// R 0x14 Product number, Low Byte
parameter P_PNO_HB       =8'hBD;// R 0x16 Product number, High Byte                                                  





