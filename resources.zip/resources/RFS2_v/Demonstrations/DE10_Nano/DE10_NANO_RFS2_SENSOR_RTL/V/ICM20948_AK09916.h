	
//--MPU9250 --SLAVE ADDRESS
parameter   [7:0] ICM20948_ADDRESS           =8'hd0;

//slave address of AK09916 is 0Ch(7bit) =0x18
parameter   [7:0] MAG_ADDRESS               =8'h18;

// ICM-20948

// USER BANK 0 REGISTER MAP
parameter P_WHO_AM_I_ICM20948  =8'h00; // Should return 0xEA
parameter P_USER_CTRL          =8'h03; // Bit 7 enable DMP, bit 3 reset DMP
parameter P_LP_CONFIG		    =8'h05; // Not found in MPU-9250
parameter P_PWR_MGMT_1         =8'h06; // Device defaults to the SLEEP mode
parameter P_PWR_MGMT_2         =8'h07; 
parameter P_INT_PIN_CFG        =8'h0F; 
parameter P_INT_ENABLE         =8'h10; 
parameter P_INT_ENABLE_1	    =8'h11; // Not found in MPU-9250
parameter P_INT_ENABLE_2	    =8'h12; // Not found in MPU-9250
parameter P_INT_ENABLE_3	    =8'h13; // Not found in MPU-9250
parameter P_I2C_MST_STATUS     =8'h17; 
parameter P_INT_STATUS         =8'h19; 
parameter P_INT_STATUS_1	    =8'h1A; // Not found in MPU-9250
parameter P_INT_STATUS_2	    =8'h1B; // Not found in MPU-9250
parameter P_INT_STATUS_3	    =8'h1C; // Not found in MPU-9250
parameter P_DELAY_TIMEH		    =8'h28;	// Not found in MPU-9250
parameter P_DELAY_TIMEL		    =8'h29;	// Not found in MPU-9250
parameter P_ACCEL_XOUT_H       =8'h2D; 
parameter P_ACCEL_XOUT_L       =8'h2E; 
parameter P_ACCEL_YOUT_H       =8'h2F; 
parameter P_ACCEL_YOUT_L       =8'h30; 
parameter P_ACCEL_ZOUT_H       =8'h31; 
parameter P_ACCEL_ZOUT_L       =8'h32; 
parameter P_GYRO_XOUT_H        =8'h33; 
parameter P_GYRO_XOUT_L        =8'h34; 
parameter P_GYRO_YOUT_H        =8'h35; 
parameter P_GYRO_YOUT_L        =8'h36; 
parameter P_GYRO_ZOUT_H        =8'h37; 
parameter P_GYRO_ZOUT_L        =8'h38; 
parameter P_TEMP_OUT_H         =8'h39; 
parameter P_TEMP_OUT_L         =8'h3A; 
parameter P_EXT_SENS_DATA_00   =8'h3B; 
parameter P_EXT_SENS_DATA_01   =8'h3C; 
parameter P_EXT_SENS_DATA_02   =8'h3D; 
parameter P_EXT_SENS_DATA_03   =8'h3E; 
parameter P_EXT_SENS_DATA_04   =8'h3F; 
parameter P_EXT_SENS_DATA_05   =8'h40; 
parameter P_EXT_SENS_DATA_06   =8'h41; 
parameter P_EXT_SENS_DATA_07   =8'h42; 
parameter P_EXT_SENS_DATA_08   =8'h43; 
parameter P_EXT_SENS_DATA_09   =8'h44;
parameter P_EXT_SENS_DATA_10   =8'h45;
parameter P_EXT_SENS_DATA_11   =8'h46;
parameter P_EXT_SENS_DATA_12   =8'h47;
parameter P_EXT_SENS_DATA_13   =8'h48;
parameter P_EXT_SENS_DATA_14   =8'h49;
parameter P_EXT_SENS_DATA_15   =8'h4A;
parameter P_EXT_SENS_DATA_16   =8'h4B;
parameter P_EXT_SENS_DATA_17   =8'h4C;
parameter P_EXT_SENS_DATA_18   =8'h4D;
parameter P_EXT_SENS_DATA_19   =8'h4E;
parameter P_EXT_SENS_DATA_20   =8'h4F;
parameter P_EXT_SENS_DATA_21   =8'h50;
parameter P_EXT_SENS_DATA_22   =8'h51;
parameter P_EXT_SENS_DATA_23   =8'h52;
parameter P_FIFO_EN_1          =8'h66;
parameter P_FIFO_EN_2          =8'h67; // Not found in MPU-9250
parameter P_FIFO_RST		       =8'h68; // Not found in MPU-9250
parameter P_FIFO_MODE		    =8'h69;// Not found in MPU-9250
parameter P_FIFO_COUNTH        =8'h70;
parameter P_FIFO_COUNTL        =8'h71;
parameter P_FIFO_R_W           =8'h72;
parameter P_DATA_RDY_STATUS	 =8'h74;// Not found in MPU-9250
parameter P_FIFO_CFG		       =8'h76;// Not found in MPU-9250
parameter P_REG_BANK_SEL	    =8'h7F;// Not found in MPU-9250
                                      
// USER BANK 1 REGISTER MAP
parameter P_SELF_TEST_X_GYRO  			=8'h02;
parameter P_SELF_TEST_Y_GYRO  			=8'h03;
parameter P_SELF_TEST_Z_GYRO  			=8'h04;
parameter P_SELF_TEST_X_ACCEL 			=8'h0E;
parameter P_SELF_TEST_Y_ACCEL 			=8'h0F;
parameter P_SELF_TEST_Z_ACCEL 			=8'h10;
parameter P_XA_OFFSET_H       			=8'h14;
parameter P_XA_OFFSET_L       			=8'h15;
parameter P_YA_OFFSET_H       			=8'h17;
parameter P_YA_OFFSET_L       			=8'h18;
parameter P_ZA_OFFSET_H       			=8'h1A;
parameter P_ZA_OFFSET_L       			=8'h1B;    
parameter P_TIMEBASE_CORRECTION_PLL	   =8'h28;

     
// USER BANK 2 REGISTER MAP
parameter P_GYRO_SMPLRT_DIV         =8'h00;  // Not found in MPU-9250
parameter P_GYRO_CONFIG_1      		=8'h01;  // Not found in MPU-9250
parameter P_GYRO_CONFIG_2      		=8'h02;  // Not found in MPU-9250
parameter P_XG_OFFSET_H       		=8'h03;  // User-defined trim values for gyroscope
parameter P_XG_OFFSET_L       		=8'h04; 
parameter P_YG_OFFSET_H       		=8'h05; 
parameter P_YG_OFFSET_L       		=8'h06; 
parameter P_ZG_OFFSET_H       		=8'h07; 
parameter P_ZG_OFFSET_L       		=8'h08; 
parameter P_ODR_ALIGN_EN			   =8'h09; // Not found in MPU-9250
parameter P_ACCEL_SMPLRT_DIV_1      =8'h10; // Not found in MPU-9250
parameter P_ACCEL_SMPLRT_DIV_2      =8'h11; // Not found in MPU-9250
parameter P_ACCEL_INTEL_CTRL		   =8'h12; // Not found in MPU-9250
parameter P_ACCEL_WOM_THR			   =8'h13; // Not found in MPU-9250 (could be WOM_THR)
parameter P_ACCEL_CONFIG      		=8'h14; 
parameter P_ACCEL_CONFIG_2     		=8'h15; // Not found in MPU-9250 (could be ACCEL_CONFIG2)
parameter P_FSYNC_CONFIG			   =8'h52; // Not found in MPU-9250
parameter P_TEMP_CONFIG				   =8'h53; // Not found in MPU-9250
parameter P_MOD_CTRL_USR			   =8'h54; // Not found in MPU-9250
                                                  

// USER BANK 3 REGISTER MAP
parameter P_I2C_MST_ODR_CONFIG		=8'h00; // Not found in MPU-9250
parameter P_I2C_MST_CTRL       		=8'h01; 
parameter P_I2C_MST_DELAY_CTRL 		=8'h02; 
parameter P_I2C_SLV0_ADDR      		=8'h03; 
parameter P_I2C_SLV0_REG       		=8'h04; 
parameter P_I2C_SLV0_CTRL      		=8'h05; 
parameter P_I2C_SLV0_DO        		=8'h06; 
parameter P_I2C_SLV1_ADDR      		=8'h07; 
parameter P_I2C_SLV1_REG       		=8'h08; 
parameter P_I2C_SLV1_CTRL      		=8'h09;    
parameter P_I2C_SLV1_DO        		=8'h0A;
parameter P_I2C_SLV2_ADDR      		=8'h0B;
parameter P_I2C_SLV2_REG       		=8'h0C;
parameter P_I2C_SLV2_CTRL      		=8'h0D;
parameter P_I2C_SLV2_DO        		=8'h0E;
parameter P_I2C_SLV3_ADDR      		=8'h0F;
parameter P_I2C_SLV3_REG       		=8'h10;
parameter P_I2C_SLV3_CTRL      		=8'h11;
parameter P_I2C_SLV3_DO        		=8'h12;
parameter P_I2C_SLV4_ADDR      		=8'h13;
parameter P_I2C_SLV4_REG       		=8'h14;
parameter P_I2C_SLV4_CTRL      		=8'h15;
parameter P_I2C_SLV4_DO        		=8'h16;
parameter P_I2C_SLV4_DI        		=8'h17; 


// See also ICM-20948 Datasheet, Register Map and Descriptions, Revision 1.3,
// https://www.invensense.com/wp-content/uploads/2016/06/DS-000189-ICM-20948-v1.3.pdf
// and AK09916 Datasheet and Register Map
// https://www.akm.com/akm/en/file/datasheet/AK09916C.pdf

//Magnetometer Registers
//--AK09916 --REGISTER
//#define AK09916_ADDRESS  0x18 
parameter P_WHO_AM_I_AK09916 =8'h01;  // (AKA WIA2) should return 0x09
parameter P_ST1              =8'h10;          // data ready status bit 0
parameter P_HXL              =8'h11;          // data
parameter P_HXH              =8'h12;
parameter P_HYL              =8'h13;
parameter P_HYH              =8'h14;
parameter P_HZL              =8'h15;
parameter P_HZH              =8'h16;
parameter P_ST2              =8'h18;  // Data overflow bit 3 and data read error status bit 2
parameter P_CNTL2            =8'h31;  // Power down (0000), single-measurement (0001), self-test (1000) and Fuse ROM (1111) modes on bits 3:0
parameter P_CNTL3            =8'h32;  // Normal (0), Reset (1)






